# -*- coding: utf-8 -*-
"""
Created on Tue Oct 19 14:05:31 2021

@author: Morihiro
"""

# imports
import numpy as np
import sys,getopt,re,struct,time,math
from pyview.lib.classes import *

from ctypes import *
import sys

class Instr(Instrument):

    """
    The (New) remote-controllable phase shiftter LPS-802 (Vaunix) instrument class
    """

    def initialize(self,*args,**kwargs):
        """
        Initializes the device.
        """
        cdll.LoadLibrary('D:\PythonLab\QuantroPyLab2\qubit_setup\instruments\VNX_dps')
        self.vnx = cdll.VNX_dps
        self.vnx.fnLPS_SetTestMode(False)
    
        DeviceIDArray = c_int * 20
        self.Devices = DeviceIDArray()           # This array will hold the list of device handles
                                        # returned by the DLL
                                        
        numDevices = self.vnx.fnLPS_GetNumDevices()
        print(str(numDevices), ' device(s) found')

        dev_info = self.vnx.fnLPS_GetDevInfo(self.Devices)
        print('GetDevInfo returned', str(dev_info))

        # GetSerialNumber will return the devices serial number
        ser_num = self.vnx.fnLPS_GetSerialNumber(self.Devices[0])
        print('Serial number:', str(ser_num))

        #InitDevice wil prepare the device for operation
        init_dev = self.vnx.fnLPS_InitDevice(self.Devices[0])
        print('InitDevice returned', str(init_dev))

    # GetNumDevices will determine how many LPS devices are availible
    
    def getNumDevices(self):
        numDevices = self.vnx.fnLPS_GetNumDevices()
        strNumDevices = str(numDevices) + ' device(s) found'
        return strNumDevices
    
    def getDeVInfo(self):
        dev_info = str(self.vnx.fnLPS_GetDevInfo(self.Devices))
        return dev_info
    
    def getSerNum(self):
        ser_num = str(self.vnx.fnLPS_GetSerialNumber(self.Devices[0]))
        return ser_num
    
    def getFrequency(self):
        freqs = self.vnx.fnLPS_GetWorkingFrequency(self.Devices[0])
        strFreqs = str(float(freqs)/10000) + ' GHz'
        
        return strFreqs
    
    def setFrequency(self, freq_GHz):
        """
        Frequency should be 8 ~ 4 GHz
        """
        while True:
            try:
                freqs = int(freq_GHz*10000)
                break
            except ValueError:
                print('freqency should be number')
        
#        print(freqs)
        max_freq = self.vnx.fnLPS_GetMaxWorkingFrequency(self.Devices[0])
        min_freq = self.vnx.fnLPS_GetMinWorkingFrequency(self.Devices[0])
#        print('min:', float(min_freq))
#        print('max:', float(max_freq))
        
        if float(max_freq) > freqs and float(min_freq) < freqs:
#            print(freqs)
            self.vnx.fnLPS_SetWorkingFrequency(self.Devices[0], int(freqs),)

        else:
            print('Set Frequency Error! Freqency should be 8 ~ 4 GHz')
            raise ValueError
        
#        current_freq = self.getFreqency()
        current_freq = self.vnx.fnLPS_GetWorkingFrequency(self.Devices[0])
        current_freq = str(float(current_freq)/10000) + ' GHz'
        
        return current_freq
            
    def getPhaseAngle(self):
        angle = self.vnx.fnLPS_GetPhaseAngle(self.Devices[0])
        strAngle = str(angle)
        return strAngle
    
    def setPhaseAngle(self,angle):
        '''
        Angle should be 0 to 360 degree.
        '''
        max_angle = self.vnx.fnLPS_GetMaxPhaseShift(self.Devices[0])
        min_angle = self.vnx.fnLPS_GetMinPhaseShift(self.Devices[0])
        
        if int(max_angle) > angle and int(min_angle) <= angle:
            self.vnx.fnLPS_SetPhaseAngle(self.Devices[0], int(angle))
        else:
            print('Set Angle Error! Anlge should be 0 ~ 360 deg')
            raise ValueError
            
        return self.getPhaseAngle()
#    
#    def setFreqRampStart(self, rampstart):
#        self.vnx.fnLPS_SetRampStart(self.Devices[0], rampstart)
#        
#        return self.getFreqRampStart()
    
    def CloseDevice(self):
        closedev = self.vnx.fnLPS_CloseDevice(self.Devices[0])
        if closedev != 0:
            print('CloseDevice returned an error', closedev)
            
        return