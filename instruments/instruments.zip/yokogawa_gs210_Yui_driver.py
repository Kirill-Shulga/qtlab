
# imports
import numpy as np
import sys,getopt,re,struct,time,math
from pyview.lib.classes import VisaInstrument

class Trace:
      pass

class Instr(VisaInstrument):

    """
    The (New) Yokogawa DC source GS200 instrument class
    """

    def initialize(self,visaAddress = "GPIB0::5::INSTR",slewrate = None,**kwargs):
      """
      Initializes the device.
      """
      try:
        self._slewrate = slewrate
        self._visaAddress = visaAddress
      except:
        self.statusStr("An error has occured. Cannot initialize Yoko(%s)." % visaAddress)        

    def setSlewrate(self,slewrate):
      self._slewrate = slewrate
      return self._slewrate

    def slewrate(self):
      return self._slewrate
         

    def getOutputValue(self):
      """
      Returns the current output in V or mA depending on the source mode
      """
      return self.ask(':SOUR:LEV?')
    
#    def _setVoltageOrCurrent(self,mode,value,slewrate,turnOn):
#      """
#      Private function for setVoltage or setCurrent
#      """
#      string = self.ask("od;")
#      if mode=='voltage' and string.find('CA')!=-1:
#        self.toVoltage()
#      elif mode=='current' and string.find('CV')!=-1:
#        self.toCurrent()
#      self.setOutputValue(value,slewrate=slewrate)
#      if turnOn:  self.turnOn()
#      return self.outputValue()

    def setOutputValue(self,value):
      """
      Switches to voltage mode if necessary, outputs voltage, and optionnaly switches output on.
      """
      self.write(':SOUR:LEV %f' % value)
      return self.getOutputValue()

    def getOutputFunction(self):
      return self.ask(':SOUR:FUNC?')

    def setVoltageMode(self):
      """
      Switches to voltage mode.
      """
      self.write(':SOUR:FUNC VOLT')
      return self.getOutputFunction()

    def setCurrentMode(self):
      """
      Switches to current mode.
      """
      self.write(':SOUR:FUNC CURR')
      return self.getOutputFunction()
      
    # def setRampToValue(self, value = 0, rampstep = 0.001, delay = 1, fdelay = 10):
    #     """
    #     ramp to the given voltage value step by step with a given step.
    #     At each step there is a delay ('delay') to stabilize.
    #     Once the final value is reached, the program have a final delay ('fdelay') time to stabilize.
    #     """
    #     xi = float(self.getOutputValue())
    #     xf = value
        
    #     if xi < xf:
    #         ramplist = [i for i in np.arange(xi, xf+rampstep, abs(rampstep))]
    #     elif xi > xf:
    #         ramplist = [i for i in np.arange(xi, xf-rampstep, -abs(rampstep))]
    #     elif xi == xf:
    #         ramplist = [0]
            
    #     for x in ramplist:
    #         self.setOutputValue(x)
    #         time.sleep(delay)
        
    #     time.sleep(fdelay)
    #     return self.getOutputValue()

##20191106 Morihiro added
    def checkVoltageRange(self, value):
        """
        Check the current voltage range is smaller than value.
        """
        rangeList = [0.01, 0.1, 1, 10, 30]

        _currentRange = float(self.ask(':SOUR:FUNC VOLT;RANG?'))
        _currentLevel = float(self.ask(':SOUR:FUNC VOLT;LEV?'))

        _value = max([value, _currentLevel])
        newRange = min([i for i in rangeList if i >= _value])

        if value > _currentRange:
          self.write(':SOUR:FUNC VOLT;RANG %f' % newRange)


##20190416 Shota added
##20191106 Morihiro modified + Yui
    def setRampToValue(self, value=0, ramprate=1, wait=True):
        """
        Ramp to the given voltage value with the given ramprate.
        The ramprate is in unit of (mV/sec). 
        The total ramp time should be less than 3600 sec.
        The voltage range is assumed to stay to prevent any abrupt pulses caused by the range change.

        Check the set value when value and slopetime is over the ranges.
        """
        self.checkVoltageRange(value) # check the range and fix if it is not in the proper level

        currentvalue = float(self.getOutputValue())
        slopetime = abs(value - currentvalue)*1000/ramprate

        # slopelist = np.linspace(currentvalue, value, 10)

        if slopetime <= 0:
            print('Slope time must be in 0 - 3600 sec.')
            return -1
        elif value > 30:
            print('Maximum output of GS200 is 30V.')
            return -1
        else:
            self.write(':PROG:SLOP %.1f' % slopetime)
            self.write(':PROG:INT %.1f' % slopetime)


        if slopetime > 3600:
            self.plogSweepOver3600(value, slopetime)
        else:
          self.write(':PROG:REP 0')
          self.write(':PROG:EDIT:STAR')
          self.write(':SOUR:LEV:FIX %f' % value)
          self.write(':PROG:EDIT:END')

          self.write(':PROG:RUN')

        if wait:
            time.sleep(slopetime)
            return self.getOutputValue()
        
        return 99 #Maximum output of GS200 is 30V. Therefore, the value '99' indicate that this function works no waiting mode. 

    def plogSweepOver3600(self, value, slopetime):
        currentvalue = float(self.getOutputValue())
        _slopelist = np.linspace(currentvalue, value, 11)
        slopelist = np.linspace(_slopelist[1],_slopelist[-1],10)

        self.write(':PROG:SLOP %.1f' % slopetime/10)
        self.write(':PROG:INT %.1f' % slopetime/10)

        self.write(':PROG:REP 0')
        self.write(':PROG:EDIT:STAR')
        for i in slopelist:
            self.write(':SOUR:LEV:FIX %f' % i)
        self.write(':PROG:EDIT:END')

        self.write(':PROG:RUN')


##20190416 Shota added end


    def saturationSweep(self, sweepRange = 0.01, rampstep = 0.0001, delay=0.002):
        currField = float(self.getOutputValue())
        targetFields = np.linspace(0, sweepRange, 5)
        for x in range(1,len(targetFields)):
            self.setRampToValue(currField + targetFields[x],rampstep,delay,1)
            self.setRampToValue(currField - targetFields[x],rampstep,delay,1)
        self.setRampToValue(currField,rampstep,delay,1)

#    def rampOutputToValue(self,value,slewrate=None,raiseError=False):
#      """
#      Sets the voltage to a given value with a given slew rate.
#      The "slew rate" is actually in V/s or A/s during the waiting time between increments.
#      Since the time to set and read the output value is not negligible with respect to the waiting time, the "slew rate" is very approximative.
#      """
#      prec=self.precision()               # determline the precision
#      if slewrate == None:  slewrate = self._slewrate        
#      if slewrate == None:
#        self.write('S%f;E;' % value)
#      else:
#        inc=max(abs(slewrate)*0.1,prec)   # and an increment larger than or equal to the precision
#        v = self.outputValue()
#        while abs(value-v) > prec:   # while you have the precision to get closer
#          time.sleep(0.1)
#          if value > v+inc:
#                v+=inc
#          elif value < v-inc:
#                v-=inc
#          else:
#            v = value
#          self.write('S%f;E;' % v)
#      v=self.outputValue()
#      if abs(v-value)>prec:
#        msg='Error: could not set the requested value!'
#        if raiseError:
#          raise msg
#        else:
#          print msg
#      return v
      
    def askOutput(self):
      """
      Returns the output status of the device (ON/OFF)
      """
      return self.ask(':OUTP?')
      
    def turnOn(self):
      """
      Turns the device on.
      """
      self.write(':OUTP ON')
      return self.askoutput()
      
    def turnOff(self):
      """
      Turns the device off.
      """
      self.write(":OUTP OFF")
      return self.output()

    def getVoltageProtection(self):
        response = self.ask(':SOUR:PROT:VOLT?')
        return response
    
    def setVoltageProtectionMax(self, value):
        self.write(':SOUR:PROT:VOLT %f' %value)
        return self.getVoltageProtection()
        
    def getCurrentProtection(self):
        response = self.ask(':SOUR:PROT:CURR?')
        return response
    
    def setCurrentProtection(self, value):
        self.write(':SOUR:PROT:CURR %f' %value)
        return self.getCurrentProtection()
        

      
#    def saveState(self,name):
#      """
#      Saves the state of the device to a dictionary.
#      """
#      self.write(':SYS:SET:SAVE')
#      return self.parameters()
#      
#    def restoreState(self,state):
#      """
#      Restores the state of the device from a dictionary.
#      """
#      self.setVoltage(state['voltage'])
#      if state['output'] == True:
#        self.turnOn()
#      else:
#        self.turnOff()
#      
#    def parameters(self):
#      """
#      Returns the parameters of the device.
#      """
#      params = dict()
#      try:
#        params['voltage'] = self.voltage()
#        params['output'] = self.output()
#        return params
#      except:
#        return "Disconnected"
#
#    def precision(self):
#      """
#      Determines the actual precision of the output
#      """
#      string = self.ask('od;E;')                  # get the actual output
#      i1 = string.find('.')
#      i2 = string.find('E',i1)                    # find the indices of the dot before the decimal part and the E before the exponent
#      decimals=i2-i1-1                            # calculate the number of digit in the decimal part
#      exponent=int(string[i2+1:])
#      prec=10**(-decimals+ exponent)           # calculate te precision
#      return prec