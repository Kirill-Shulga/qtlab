# -*- coding: utf-8 -*-
"""
Created on Thu Aug 11 15:17:03 2016

Instrument scripts for Agilent E3633A DC power supply

@author: HyQu
"""

import sys
import ctypes
import getopt
import re
import struct
import time


from pyview.lib.classes import VisaInstrument
#from lib.swig.tools import numerical
import numpy as np

__DEBUG__=True


#This is the CS instrument.
class Instr(VisaInstrument):

    def initialize(self, visaAddress = 'GPIB0::11::INSTR'):
        try:
          print "Initializing instrument E3633 with address %s" % visaAddress
          self._visaAddress = visaAddress
        except:
          self.statusStr("An error has occured. Cannot initialize Lecroy 104Xi.")

    
#    def initialize(self, visaAddress = "GPIB0::11::INSTR"):
#        """
#          Initializes the device.
#          """
#        try:
#            self._visaAddress = visaAddress
#            self._currRate=1E-3                             # rate A/sec
#            self._voltRate=1E-3                             # rate V/sec
#            self._currStep=1E-3                             # amps
#            self._voltStep=1E-3                             # volts
#            self._targetCurrent=None
#        except:
#            self.statusStr("An error has occured. Cannot initialize Agilent CS(%s)." % visaAddress)     
            
    def askOutput(self):
        return self.ask('OUTP:STAT?')
    
    def turnOn(self):
        self.write('OUTP:STAT ON')
        return self.askOutput()
    
    def turnOff(self):
        self.write('OUTP:STAT OFF')
        return self.askOutput()
    
    def setTargetCurrent (self, targetCurrent):
        self._targetCurrent=targetCurrent
        
    def getTargetCurrent (self):
        return self._targetCurrent
        
    def setCurrentStep(self, currStep):
        self._currStep=currStep
    
    def getVoltStep(self):
        return float(self.ask('VOLT:STEP?'))

    def setVoltStep(self, voltStep = 0.001):
        self.write('VOLT:STEP %s' %voltStep)
        self.getVoltStep()

    def DoVoltStepUp(self):
        self.write('VOLT UP')
    
    def DoVoltStepDown(self):
        self.write('VOLT DOWN')
  #  def setCurrentRate(self, currRate):
  #      return self._currRate=currRate
    
    def setVoltRate(self, voltRate):
        self._voltRate=voltRate        
    
    def getProtectionState(self, CONT = 'VOLT'):
        response = self.ask('%s:PROT:STAT?' %CONT)
        return response
    
    def setProtectionState(self, CONT = 'VOLT', STATe = 'ON'):
        self.write('%s:PROT:STAT %s' % (CONT, STATe))
    
    def getVoltageProtection(self):
        response = self.ask('VOLT:PROT?')
        return response
    
    def setVoltageProtection(self, value):
        self.write('VOLT:PROT %f' %value)
        return self.getVoltageProtection()
        
    def getCurrentProtection(self):
        response = self.ask('CURR:PROT?')
        return response
    
    def setCurrentProtection(self, value):
        self.write('CURR:PROT %f' %value)
        return self.getCurrentProtection()
    
    def currentDelay(self):
        self.currDelay=self._currStep/self._currRate
        return self.currDelay
    
    def voltageDelay(self):
        self.voltDelay=self._voltStep/self._voltRate
        return self.voltDelay
       
    def getVoltageMeas(self):
        return float(self.ask('MEAS:VOLT?'))

    def getVoltage(self):
        return float(self.ask('VOLT?'))
        
    def getCurrentMeas(self):
        return float(self.ask('MEAS:CURR?'))

    def getCurrent(self):
        return float(self.ask('CURR?'))
        
    def setCurrent(self, value):
        self.write('CURR %f' % value)
        return self.getCurrent()
    
    def setVoltage(self, value):
        self.write('VOLT %f' % value)
        return self.getVoltage()
    
    def reloadCurrState (self):
        if self.askOutput()=='0':
            self.setCurrent(0.000)
            self.turnOn()
        self.startV=round(self.getVoltage(),3)
        self.startI=round(self.getCurrent(),3)

    def goToVoltage (self, value = 0.1, timedelay = 0.1):
        # 'value' is the target value
    ##### Be sure that you put the voltstep properly!!!! with +/- sign!!!!  ###### 
        a = "%.4f" % self.getVoltage()  # trancate until the 3rd digit
        Voltagevalue = float(a)         # back to floating number
        
        voltstep = self.getVoltStep()   # get voltage step
        voltlist = np.arange(Voltagevalue, value + voltstep, voltstep)     #make a list (array)

        for x in voltlist:
            xstr = '%.4f' % x
            xvalue = float(xstr)
            self.setVoltage(xvalue)
            print self.getVoltage()
            time.sleep(timedelay)
        
#        if direc == 'Up':
#            while (value > self.getVoltage()):
#                self.DoVoltStepUp()
#                time.sleep(timedelay)
#
#        elif direc == 'Down':
#            while (value < self.getVoltage()):
#                self.DoVoltStepDown()
#                time.sleep(timedelay)
                    
    def goToCurrent (self):
        self.reloadCurrState()               
        if self.startI>self._targetCurrent:
            self.write('CURR:STEP %f' % -self._currStep)
        else:
            self.write('CURR:STEP %f' % self._currStep)
        
        if (self._targetCurrent != None and self._targetCurrent != 0.000):
            n=int(abs(self.startI-self._targetCurrent)/self._currStep)
            delay=self.currentDelay()                      
            for i in range(0,n):                    
                try:                    
                    self.write('CURR UP')
                    time.sleep(delay)
                except KeyboardInterrupt:
                    print  'Interrupted by user'
                    sys.exit()                
            if (abs(self.getCurrent()-self._targetCurrent)<2E-3):
                self.setCurrent(self._targetCurrent)
    
        elif (self._targetCurrent == 0.000 ):
            n=int(abs(self.startI-self._targetCurrent)/self._currStep)
            delay=self.currentDelay()        
            for i in range(0,n-1):
                try:                
                    self.write('CURR UP')
                    time.sleep(delay)
                except KeyboardInterrupt:
                    print  'Interrupted by user'
                    sys.exit()
            self.setCurrent(0)
            
        else:
            print "Set the value of target current"        
    