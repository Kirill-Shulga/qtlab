
# imports
import numpy as np
import sys,getopt,re,struct,time,math
from pyview.lib.classes import VisaInstrument

class Instr(VisaInstrument):
    
    """
    The American Magnetics Inc model 430 instrument class
    by J. Ball, April-May 2020
    Get setpoint added by YK, Feb 2021
    """

    def initialize(self,visaAddress = 'TCPIP0::192.168.0.41::7180::SOCKET', termchars='\r\n', **kwargs):
      """
      Initializes the device.
      """
      try:
        self.debugPrint('Initializing AMI model 430...')
        self._visaAddress = visaAddress
        self.read()
        print self.read()
        field = float(self.ask("FIELD:UNITS?"))
        rate = float(self.ask("RAMP:RATE:UNITS?"))
        if (field == 1 and rate == 0):
            print ("Units are T/sec")
        else:
            print ("Units are NOT T/sec. Proceed with caution")
      except:
        self.statusStr("An error has occured. Cannot initialize AMI Model 430.")        

    def canStartRamp(self):
        if float(self.ask("QU?")) == 1: #check for quench
            print ("Could not ramp due to quench")
            return False
            
        state = self.getRampingState()
        if state == 1:
            print ("YOU ARE ALREADY RAMPING")
            return False
        elif state == 2 or 3 or 8:
            return True
        
        return False

    def FieldRamp(self, value):
        """
        Ramp to a certain field

        """
        if not self.canStartRamp():  
            return 'cannot start ramping yet'
        
        # Check we aren't violating field limits
        field_lim = self.getFieldLim()
        if np.abs(value) > field_lim:
            return 'Field limit exceeded'
        # Then, do the actual ramp
        # Set the ramp target
        self.write("CONF:FIELD:TARG %f" % value)
        
        self.write("RAMP")
        state = float(self.getRampingState())
        while state == 1:
            state = float(self.ask("STATE?"))
            time.sleep(0.3)
        time.sleep(2.0)
        
        # If we are now holding, it was successful
        if state != 2:
            return 'setField failed.'
            
    def getRampingState(self):
        results = self.ask("STATE?")     
        return results

    def getCurrentLimit(self):
        results = self.ask("CURR:LIM?")
        return float(results)
        
    def getVoltageLimit(self):
        results = self.ask("VOLT:LIM?")
        return float(results)
        
    def getFieldLim(self):
        field_lim = float(self.ask("COIL?"))*self.getCurrentLimit()
        return float(field_lim)
        
    def getField(self): #this is the current field
        results = self.ask("FIELD:MAG?")
        return float(results)
 
    def getFieldSetpoint(self): #this is the current field
        results = self.ask("FIELD:TARG?")
        return float(results)
  
    def getCurrent(self): #this is the current ... current?
        results = self.ask("CURRENT:MAG?")
        return float(results)

    def getCurrentSetpoint(self): #this is the current field
        results = self.ask("CURR:TARG?")
        return float(results)
        
    def getRampRate(self):
        """ Return the ramp rate of the first segment in Tesla per second """
        results = self.ask('RAMP:RATE:FIELD:1?').split(',')
        return float(results[0])
        
    def setCurrentLimit(self, value):
        if value > 58: #Maximum current amplitude in AMI (xy) split coil
            return "That current limit exceeds value on AMI datasheet"
        self.write("CONF:CURR:LIM %f" % value)        
        return

    def setVoltageLimit(self, value):
        self.write("CONF:VOLT:LIM %f" % value)        
        return         
            
    def setRampRate(self, rate):
        """ Set the ramp rate of the first segment in Amperes per second """
        if rate > 0.290*float(self.ask("COIL?")): #current ramp limit of AMI (xy) split coil in Amps/sec
            return "The rate is too damn high!"
        self.write("CONF:RAMP:RATE:SEG 1")
        self.write("CONF:RAMP:RATE:FIELD 1,%f,0" % rate)