# -*- coding: utf-8 -*-
"""
Code for Agilent Oscilloscope

Created on Tue Nov 01 14:27:01 2016

@author: HyQu
"""

import sys
import getopt
import re
import struct
import numpy as np

from pyview.lib.datacube import Datacube

sys.path.append('.')
sys.path.append('../')

from pyview.lib.classes import *


class Instr(VisaInstrument):

    def parameters(self, lazy=True):
        return self._params

    def initialize(self, visaAddress='TCPIP0::192.168.0.39::inst0::INSTR'):
        try:
            print "Initializing the Agilent MSO7054A with address %s" % visaAddress
            self._visaAddress = visaAddress
        except:
            self.statusStr("An error has occured. Cannot initialize Agilent MSO7054A.")

    def getActiaveChannel(self):
        response = self.ask('WAV:SOUR?')
        return response

    def setActiaveChannel(self, channel=1):
        self.write('WAV:SOUR CHAN%i' % channel)
        response = self.ask('WAV:SOUR?')
        return response

    def getCommunicationSettings(self):
        # wave data format
        response1 = self.ask("WAV:FORM?")
        # byte order
        response2 = self.ask('WAV:BYT?')
        # data record mode
        response3 = self.ask("WAV:POIN:MODE?")
        return response1 + " " + response2 + " " + response3

    def getActiveChannels(self):
        ActiveChannels = []
        for channel in range(1, 5):
            onoff = self.ask('CHAN%i' % channel + ':DISP?')
            if onoff == '1':
                ActiveChannels.append(channel)
        return ActiveChannels

    def setChannelDisplayONOFF(self, channel=1, onoff=1):
        oscillo.write('CHAN%i:DISP %i' % (channel, onoff))
        response = self.ask('CHAN%i' % channel + ':DISP?')
        return response

    def setCommunicationSettings(self, comm_Format="ASC", comm_Byte="MSBF", comm_Mode="NORM"):
        self.write("WAV:FORM " + comm_Format)
        self.write("WAV:BYT " + comm_Byte)
        self.write("WAV:POIN:MODE " + comm_Mode)
        return self.getCommunicationSettings()

    def getParameters(self):
        # get preamble strings for the current active channel
        preamblestr = self.ask("WAV:PRE?")
        preamblestr = preamblestr.split(',')
        response = 'Format: ' + preamblestr[0] + '\nType: ' + preamblestr[1] + '\n'
        response += response + 'Points: ' + preamblestr[2] + '\nCount: ' + preamblestr[3] + '\n'
        response += 'xIncrement: ' + preamblestr[4] + '\nXorigin: ' + preamblestr[5] + '\n'
        response += 'xReference: ' + preamblestr[6] + '\nyIncrement: ' + preamblestr[7] + '\n'
        response += 'yOrigin: ' + preamblestr[8] + '\nyReference: ' + preamblestr[9]
        return response

    def getMarkerValues(self):
        # get marker values
        response = 'Marker Values\nMode: ' + self.ask("MARK:MODE?") + "\n"
        response += 'Marker 1: (' + self.ask("MARK:X1P?") + ', ' + self.ask("MARK:Y1P?") + ')\n'
        response += 'Marker 2: (' + self.ask("MARK:X2P?") + ', ' + self.ask("MARK:Y2P?") + ')\n'
        return response

    def getWaveForms(self):
        # get wave forms
        d = Datacube('waveform')
        ActiveChannels = self.getActiveChannels()
        for channel in ActiveChannels:
            self.write('WAV:SOUR CHAN%i' % channel)
            r = self.ask('WAV:DATA?')[10:]  # get a waveform data array #remove the unneccesary string '\r\n'
            # convert to floating points format  # map might work but just in case where there are null str
            r = r.split(",")
            r = [float(x) if x != '' else 0 for x in r]
            d.createColumn("C%i" % channel, r)

        # get x-axis (time) interval and offset to make an x axis of the plot
        hi = self.ask('WAV:XINC?')
        hi = float(hi)
        ho = self.ask('TIM:POS?')
        ho = float(ho)
        # make an array with all zero and then put the time values
        t = np.zeros(len(r))
        for i in range(len(r)):
            t[i] = ho + i * hi

        d.createColumn('time', t)
        return d

    def clearDisplay(self):
        # CLear_SWeeps
        self.write("CDIS")
        return "clear sweep command sent"

    def Acquire(self):
        # trigger one measurement
        self.write("CDIS")
        return "clear sweep command sent"
