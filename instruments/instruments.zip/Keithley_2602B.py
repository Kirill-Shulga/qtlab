import sys
import getopt
import time

from pyview.lib.classes import *
from pyview.lib.datacube import *

""" MODIFIED BY DV IN DEC 2014"""


# This is the Keithley_2602B Sourcemeter instrument.
# As a visa instrument, it is also an Instrument and a ThreadedDispatcher.
class Instr(VisaInstrument):

  """
  The Keithley_2602B Sourcemeter instrument class.
  """

  def initialize(self,visaAddress="TCPIP0::192.168.0.74::inst0",**kwargs):
    try:
      self.debugPrint('Initializing SMU')
      self._visaAddress = visaAddress
    except:
      pass 
    

  def __ch(self,channel):
  	  '''
  	  helper function
  	  converts channel=1 to smua
  	  and channel=2 to smub
  	  '''
  	  if channel==1:
  	  	return 'smua'
  	  elif channel==2:
  	  	return 'smub'

  #########################
  #  BASIC SETS AND GETS  #
  #########################

  def reset(self):
      '''
      Resets the instrument to default values

      Input:
          None

      Output:
          None
      '''
      self.write("reset()")

  def get_status(self,channel):
      '''
      Reads the output status from the instrument

      Input:
          None

      Output:
          status (bool) : True='On' or False='Off'
      '''
      stat = int(float(self.ask('print('+self.__ch(channel)+'.source.output)').strip()))

      if (stat==1):
        return True
      elif (stat==0):
        return False
      else:
        raise ValueError('Output status not specified : %s' % stat)
      return

  def set_status(self, channel, status):
      '''
      Set the output status of the instrument

      Input:
          status (bool) : True='On' or False='Off'

      Output:
          None
      '''          
      if status == True:
          self.write(self.__ch(channel)+'.source.output = 1')
      else:
          self.write(self.__ch(channel)+'.source.output = 0')

##all about setting currents and voltages
  def get_voltage(self,channel):
      '''
      Reads the phase of the signal from the instrument

      Input:
          None

      Output:
          volt (float) : Voltage in Volts
      '''
      return float(self.ask('print('+self.__ch(channel)+'.measure.v())').strip())

  def set_voltage(self, channel, volt):
      '''
      Set the Amplitude of the signal

      Input:
          volt (float) : voltage in volt

      Output:
          None
      '''
      self.write(self.__ch(channel)+'.source.levelv = %s' % volt)


  def get_current(self, channel):
      '''
      Reads the phase of the signal from the instrument

      Input:
          None

      Output:
          current (float) : current in amps
      '''
      return float(self.ask('print('+self.__ch(channel)+'.measure.i())').strip())

  def set_current(self, channel, curr):
      '''
      Set the Amplitude of the signal

      Input:
          curr (float) : current in amps

      Output:
          None
      '''
      self.write(self.__ch(channel)+'.source.leveli = %s' % curr)


  def set_digIO(self,channel,value):
  	  '''
  	  there are 14 digital channels, 
  	  which can take values of 0 or 1,
  	  which causes an output voltage of
  	  0 and 5 V, respectively
  	  '''
  	  self.write('digio.writebit('+str(channel)+', '+str(value)+')')

  #########################
  #  OPERATING MODES  #
  #########################

  def set_measureautorange_voltage(self,channel,enabled=True):
  	  '''
  	  status (bool): switches autorange on or off
  	  '''
  	  self.write(self.__ch(channel)+'.measure.autorangev = %s' % int(enabled))

  def set_measureautorange_current(self,channel,enabled=True):
  	  '''
  	  status (bool): switches autorange on or off
  	  '''
  	  self.write(self.__ch(channel)+'.measure.autorangei = %s' % int(enabled))

  def set_sourceautorange_voltage(self,channel,enabled=True):
  	  '''
  	  status (bool): switches autorange on or off
  	  '''
  	  self.write(self.__ch(channel)+'.source.autorangev = %s' % int(enabled))

  def set_sourceautorange_current(self,channel,enabled=True):
  	  '''
  	  status (bool): switches autorange on or off
  	  '''
  	  self.write(self.__ch(channel)+'.source.autorangei = %s' % int(enabled))

  def set_measurerange_voltage(self,channel,rangeval):
  	  '''
  	  status (bool): switches autorange on or off
  	  '''
  	  self.write(self.__ch(channel)+'.measure.rangev = %f' % rangeval)

  def set_measurerange_current(self,channel,rangeval):
  	  '''
  	  status (bool): switches autorange on or off
  	  '''
  	  self.write(self.__ch(channel)+'.measure.rangei = %f' % rangeval)

  def set_sourcerange_voltage(self,channel,rangeval):
  	  '''
  	  status (bool): switches autorange on or off
  	  '''
  	  self.write(self.__ch(channel)+'.source.rangev = %f' % rangeval)

  def set_sourcerange_current(self,channel,rangeval):
  	  '''
  	  status (bool): switches autorange on or off
  	  '''
  	  self.write(self.__ch(channel)+'.source.rangei = %f' % rangeval)


  def set_voltagelimit(self,channel,limit):
  	  '''
  	  set a voltage limit
  	  '''
  	  self.write(self.__ch(channel)+'.source.limitv = %f' % limit)

  def set_currentlimit(self,channel,limit):
  	  '''
  	  set a voltage limit
  	  '''
  	  self.write(self.__ch(channel)+'.source.limiti = %f' % limit)


  def set_currentsource(self,channel):
  	  '''
  	  enables current source mode
  	  '''
  	  self.write(self.__ch(channel)+'.source.func = '+self.__ch(channel)+'.OUTPUT_DCAMPS')

  def set_voltagesource(self,channel):
  	  '''
  	  enables current source mode
  	  '''
  	  self.write(self.__ch(channel)+'.source.func = '+self.__ch(channel)+'.OUTPUT_DCVOLTS')


  #########################
  #  SWEEPING VOLTAGES AND CURRENTS  #
  #########################
  
    
