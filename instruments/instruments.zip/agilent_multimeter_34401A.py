import sys,getopt,re,struct,time,math
from pyview.lib.classes import VisaInstrument

class Trace:
      pass

class Instr(VisaInstrument):

    """
    The Agilent multimeter instrument class
    """

    def initialize(self,visaAddress = "GPIB0::23",slewrate = None,**kwargs):
      """
      Initializes the device.
      """
      try:
        self._slewrate = slewrate
        self._visaAddress = visaAddress
      except:
        self.statusStr("An error has occured. Cannot initialize agilent Multimeter(%s)." % visaAddress)        

    def setSlewrate(self,slewrate):
      self._slewrate = slewrate
      return self._slewrate

    def slewrate(self):
      return self._slewrate
      
      
# get measurements, with preset setting, functions
      
    def get_VoltageDC(self, rg = 'DEF', res = 'DEF') :
          return self.ask(":MEAS:VOLT:DC? %s, %s" %(rg, res))
          
    def get_VoltageDCRatio(self, rg = 'DEF', res = 'DEF') :
          return self.ask(":MEAS:VOLT:DC:RAT? %s, %s" %(rg, res))
          
    def get_VoltageAC(self, rg = 'DEF', res = 'DEF') :
          return self.ask(":MEAS:VOLT:AC? %s, %s" %(rg, res))
          
    def get_CurrentDC(self, rg = 'DEF', res = 'DEF') :
          return self.ask(":MEAS:CURR:DC? %s, %s" %(rg, res))
          
    def get_CurrentAC(self, rg = 'DEF', res = 'DEF') :
          return self.ask(":MEAS:CURR:AC? %s, %s" %(rg, res))
          
    def get_Resistance(self, rg = 'DEF', res = 'DEF') :
          return self.ask(":MEAS:RES? %s, %s" %(rg, res))
          
    def get_4WireResistance(self, rg = 'DEF', res = 'DEF') :
          return self.ask(":MEAS:FRES? %s, %s" %(rg, res))
          
    def get_Frequency(self, rg = 'DEF', res = 'DEF') :
          return self.ask(":MEAS:FREQ? %s, %s" %(rg, res))
          
    def get_Period(self, rg = 'DEF', res = 'DEF') :
          return self.ask(":MEAS:PER? %s, %s" %(rg, res))
          
          
# set configuration, with preset setting, functions
          
    def set_VoltageDC(self, rg = 'DEF', res = 'DEF') :
          return self.write(":CONF:VOLT:DC %s, %s" %(rg, res))
          
    def set_VoltageDCRatio(self, rg = 'DEF', res = 'DEF') :
          return self.write(":CONF:VOLT:DC:RAT %s, %s" %(rg, res))
          
    def set_VoltageAC(self, rg = 'DEF', res = 'DEF') :
          return self.write(":CONF:VOLT:AC %s, %s" %(rg, res))
          
    def set_CurrentDC(self, rg = 'DEF', res = 'DEF') :
          return self.write(":CONF:CURR:DC %s, %s" %(rg, res))
          
    def set_CurrentAC(self, rg = 'DEF', res = 'DEF') :
          return self.write(":CONF:VOLT:AC %s, %s" %(rg, res))
          
    def set_Resistance(self, rg = 'DEF', res = 'DEF') :
          return self.write(":CONF:RES %s, %s" %(rg, res))
          
    def set_4WireResistance(self, rg = 'DEF', res = 'DEF') :
          return self.write(":CONF:FRES %s, %s" %(rg, res))
          
    def set_Frequency(self, rg = 'DEF', res = 'DEF') :
          return self.write(":CONF:FREQ %s, %s" %(rg, res))
          
    def set_Period(self, rg = 'DEF', res = 'DEF') :
          return self.write(":CONF:PER %s, %s" %(rg, res))
          
    #ask configuration 
    def get_Configuration(self) :
          return self.ask(":CONF?")   
          
          
# set multimeter functions
          
    def set_function_VoltageDC(self) :
          return self.write(':FUNC "VOLT:DC"')
          
    def set_function_VoltageDCRatio(self) :
          return self.write(':FUNC "VOLT:DC:RAT"') 
          
    def set_function_VoltageAC(self) :
          return self.write(':FUNC "VOLT:AC"')   
          
    def set_function_CurrentDC(self) :
          return self.write(':FUNC "CURR:DC"')
                    
    def set_function_CurrentAC(self) :
          return self.write(':FUNC "CURR:AC"')
                              
    def set_function_Resistance(self) :
          return self.write(':FUNC "RES"')
                                        
    def set_function_4WireResistance(self) :
          return self.write(':FUNC "FRES"')
                                                  
    def set_function_Frequency(self) :
          return self.write(':FUNC "FREQ"')
                                                            
    def set_function_Period(self) :
          return self.write(':FUNC "PER"')
          
# set multimeter range
          
    def set_range_VoltageDC(self, rg = "MAX") :
          return self.write(':VOLT:DC:RANG %s' %rg)
          
    def set_range_VoltageAC(self, rg = "MAX") :
          return self.write(':VOLT:AC:RANG %s' %rg)   
          
    def set_range_CurrentDC(self, rg = "MAX") :
          return self.write(':CURR:DC:RANG %s' %rg)
                    
    def set_range_CurrentAC(self, rg = "MAX") :
          return self.write(':CURR:AC:RANG %s' %rg)
                              
    def set_range_Resistance(self, rg = "MAX") :
          return self.write(':RES:RANG %s' %rg)
                                        
    def set_range_4WireResistance(self, rg = "MAX") :
          return self.write(':FRES:RANG %s' %rg)
                                                  
    def set_range_Frequency(self, rg = "MAX") :
          return self.write(':FREQ:RANG %s' %rg)
                                                            
    def set_range_Period(self, rg = "MAX") :
          return self.write(':PER:RANG %s' %rg)
          
    # ask range
          
    def get_range_VoltageDC(self, rg = "") :
          return self.ask(':VOLT:DC:RANG? %s' %rg)
          
    def get_range_VoltageAC(self, rg = "") :
          return self.ask(':VOLT:AC:RANG? %s' %rg)   
          
    def get_range_CurrentDC(self, rg = "") :
          return self.ask(':CURR:DC:RANG? %s' %rg)
                    
    def get_range_CurrentAC(self, rg = "") :
          return self.ask(':CURR:AC:RANG? %s' %rg)
                              
    def get_range_Resistance(self, rg = "") :
          return self.ask(':RES:RANG? %s' %rg)
                                        
    def get_range_4WireResistance(self, rg = "") :
          return self.ask(':FRES:RANG? %s' %rg)
                                                  
    def get_range_Frequency(self, rg = "") :
          return self.ask(':FREQ:RANG? %s' %rg)
                                                            
    def get_range_Period(self, rg = "") :
          return self.ask(':PER:RANG? %s' %rg)
          
# On/off autorange (default value : "ON")
          
    def set_autorange_VoltageDC(self, auto = "ON") :
          return self.write(':VOLT:DC:RANG:AUTO %s' %auto)
          
    def set_autorange_VoltageAC(self, auto = "ON") :
          return self.write(':VOLT:AC:RANG:AUTO %s' %auto)   
          
    def set_autorange_CurrentDC(self, auto = "ON") :
          return self.write(':CURR:DC:RANG:AUTO %s' %auto)
                    
    def set_autorange_CurrentAC(self, auto = "ON") :
          return self.write(':CURR:AC:RANG:AUTO %s' %auto)
                              
    def set_autorange_Resistance(self, auto = "ON") :
          return self.write(':RES:RANG:AUTO %s' %auto)
                                        
    def set_autorange_4WireResistance(self, auto = "ON") :
          return self.write(':FRES:RANG:AUTO %s' %auto)
                                                  
    def set_autorange_Frequency(self, auto = "ON") :
          return self.write(':FREQ:RANG:AUTO %s' %auto)
                                                            
    def set_autorange_Period(self, auto = "ON") :
          return self.write(':PER:RANG:AUTO %s' %auto)
          
    
    # ask On/off autorange
    
    def get_autorange_VoltageDC(self) :
          return self.ask(':VOLT:DC:RANG:AUTO?')
          
    def get_autorange_VoltageAC(self) :
          return self.ask(':VOLT:AC:RANG:AUTO?')   
          
    def get_autorange_CurrentDC(self) :
          return self.ask(':CURR:DC:RANG:AUTO?')
                    
    def get_autorange_CurrentAC(self) :
          return self.ask(':CURR:AC:RANG:AUTO?')
                              
    def get_autorange_Resistance(self) :
          return self.ask(':RES:RANG:AUTO?')
                                        
    def get_autorange_4WireResistance(self) :
          return self.ask(':FRES:RANG:AUTO?')
                                                  
    def get_autorange_Frequency(self) :
          return self.ask(':FREQ:RANG:AUTO?')
                                                            
    def get_autorange_Period(self) :
          return self.ask(':PER:RANG:AUTO?')
          
# set multimeter resolution
          
    def set_resolution_VoltageDC(self, res = "MAX") :
          return self.write(':VOLT:DC:RES %s' %res)
          
    def set_resolution_VoltageAC(self, res = "MAX") :
          return self.write(':VOLT:AC:RES %s' %res)   
          
    def set_resolution_CurrentDC(self, res = "MAX") :
          return self.write(':CURR:DC:RES %s' %res)
                    
    def set_resolution_CurrentAC(self, res = "MAX") :
          return self.write(':CURR:AC:RES %s' %res)
                              
    def set_resolution_Resistance(self, res = "MAX") :
          return self.write(':RES:RES %s' %res)
                                        
    def set_resolution_4WireResistance(self, res = "MAX") :
          return self.write(':FRES:RES %s' %res)
                                                  
    def set_resolution_Frequency(self, res = "MAX") :
          return self.write(':FREQ:RES %s' %res)
                                                            
    def set_resolution_Period(self, res = "MAX") :
          return self.write(':PER:RES %s' %res)
          
    # ask resolution
          
    def get_resolution_VoltageDC(self, res = "") :
          return self.ask(':VOLT:DC:RES? %s' %res)
          
    def get_resolution_VoltageAC(self, res = "") :
          return self.ask(':VOLT:AC:RES? %s' %res)   
          
    def get_resolution_CurrentDC(self, res = "") :
          return self.ask(':CURR:DC:RES? %s' %res)
                    
    def get_resolution_CurrentAC(self, res = "") :
          return self.ask(':CURR:AC:RES? %s' %res)
                              
    def get_resolution_Resistance(self, res = "") :
          return self.ask(':RES:RES? %s' %res)
                                        
    def get_resolution_4WireResistance(self, res = "") :
          return self.ask(':FRES:RES? %s' %res)
                                                  
    def get_resolution_Frequency(self, res = "") :
          return self.ask(':FREQ:RES? %s' %res)
                                                            
    def get_resolution_Period(self, res = "") :
          return self.ask(':PER:RES? %s' %res)
          
# set multimeter NPL cycles
          
    def set_NPLCycles_VoltageDC(self, nplc = "10") :
          return self.write(':VOLT:DC:NPLC %s' %nplc)
          
    def set_NPLCycles_VoltageAC(self, nplc = "10") :
          return self.write(':VOLT:AC:NPLC %s' %nplc)   
          
    def set_NPLCycles_CurrentDC(self, nplc = "10") :
          return self.write(':CURR:DC:NPLC %s' %nplc)
                    
    def set_NPLCycles_CurrentAC(self, nplc = "10") :
          return self.write(':CURR:AC:NPLC %s' %nplc)
                              
    def set_NPLCycles_Resistance(self, nplc = "10") :
          return self.write(':RES:NPLC %s' %nplc)
                                        
    def set_NPLCycles_4WireResistance(self, nplc = "10") :
          return self.write(':FRES:NPLC %s' %nplc)
          
    # ask NPL cycles 
          
    def get_NPLCycles_VoltageDC(self, nplc = "") :
          return self.ask(':VOLT:DC:NPLC? %s' %nplc)
          
    def get_NPLCycles_VoltageAC(self, nplc = "") :
          return self.ask(':VOLT:AC:NPLC? %s' %nplc)   
          
    def get_NPLCycles_CurrentDC(self, nplc = "") :
          return self.ask(':CURR:DC:NPLC? %s' %nplc)
                    
    def get_NPLCycles_CurrentAC(self, nplc = "") :
          return self.ask(':CURR:AC:NPLC? %s' %nplc)
                              
    def get_NPLCycles_Resistance(self, nplc = "") :
          return self.ask(':RES:NPLC? %s' %nplc)
                                        
    def get_NPLCycles_4WireResistance(self, nplc = "") :
          return self.ask(':FRES:NPLC? %s' %nplc)   
          
# set frequency and period aperture time
          
    def set_aperture_Frequency(self, aperture = "0.1") :
          return self.write(':FREQ:APER %s' %aperture)
                                                            
    def set_aperture_Period(self, aperture = "0.1") :
          return self.write(':PER:APER %s' %aperture)  
          
    # ask frequency and period aperture time
          
    def get_aperture_Frequency(self, aperture = "") :
          return self.ask(':FREQ:APER? %s' %aperture)
                                                            
    def get_aperture_Period(self, aperture = "") :
          return self.ask(':PER:APER? %s' %aperture)
          
          
# set detector bandwidth (AC filter)
          
    def set_DetectorBW(self, bw = "20") :
          return self.write(':DET:BAND %s' %bw)    
          
    # ask detector bandwidth
        
    def get_DetectorBW(self, bw = "") :
          return self.ask(':DET:BAND? %s' %bw) 
          

# set autozero mode
          
    def set_AutoZero(self, az = "ON") :
          return self.write(':ZERO:AUTO %s' %az)    
          
    # ask detector bandwidth
        
    def get_AutoZero(self, az = "ON") :
          return self.ask(':ZERO:AUTO? %s' %az) 
          
# set input impedance
          
    def set_InputImpedance(self, imp = "OFF") :
          return self.write(':INP:IMP:AUTO %s' %imp)    
          
    # ask detector bandwidth
        
    def get_InputImpedance(self) :
          return self.ask(':INP:IMP:AUTO?')       
          
######################## Triggering ###############################

    def set_Tigger_source(self, source = "IMM") :
          return self.write(':TRIG:SOUR %s' %source)
          
    def set_Tigger_autodelay(self, mode = "ON") :
          return self.write(':TRIG:DEL:AUTO %s' %mode)
          
    def set_Tigger_delay(self, delay = "MIN") :
          return self.write(':TRIG:DEL %s' %delay)
          
    def set_Tigger_count(self, count = "1") :
          return self.write(':TRIG:COUN %s' %count)
          
    def set_Sample_count(self, count = "1") :
          return self.write(':SAMP:COUN %s' %count)
          
    # ask trigger configuration
          
    def get_Tigger_source(self) :
          return self.ask(':TRIG:SOUR %s')
          
    def get_Tigger_autodelay(self, mode = "") :
          return self.ask(':TRIG:DEL:AUTO %s' %mode)
          
    def get_Tigger_delay(self) :
          return self.ask(':TRIG:DEL %s')
          
    def get_Tigger_count(self, count = "") :
          return self.ask(':TRIG:COUN %s' %count)
          
    def get_Sample_count(self, count = "") :
          return self.ask(':SAMP:COUN %s' %count)   
          
###################### System-related Commands ################################
          
# Reading
          
    def read(self) :
          return self.ask(':READ?')    
          
    def initiate(self) :
          return self.write(':INIT')
          
    def fetch(self) :
          return self.ask(':FETC?')
          
# System error
          
    def error_request(self) :
          return self.ask(':SYST:ERR?')   