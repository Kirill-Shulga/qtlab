import sys
import getopt
import time

from pyview.lib.classes import *
from pyview.lib.datacube import *

## Created by J BALL in FEB 2018 ##

class Trace:
  """
  A class storing trace data for the FSP.
  """
  def __init__(self):
    self.frequencies = []
    self.times = []
    self.magnitude = []
    self.timestamp = ''
    self.instrument = None

# Spectrum Analyzer.
class Instr(VisaInstrument):

  def initialize(self,visaAddress="TCPIP0::192.168.0.32::inst0",**kwargs): #32 chosen as IP address
    try:
        self.debugPrint('Initializing SPA')
        self._visaAddress = visaAddress
        self.lastTrace=Trace()
        self.transferIndex=0
    except:
        self.statusStr("An error has occured. Cannot initialize SPA.")

  def getValueAtMarker(self):
    return float(self.ask("MKL?"))

  def trigGen(self):
    self.write("RAD:ARB:TRIG:GEN")

  def getFrequencyInGHz(self): #Done
    return float(self.ask("FREQ:CENT?"))/1e9

  def setFrequencyInGHz(self,freq):
    self.write("FREQ:CENT %f GHZ" %freq)
    return self.getFrequencyInGHz()

  def getSpanInGHz(self):
    return float(self.ask("FREQ:SPAN?"))/1e9

  def setSpanInGHz(self,span):
    self.write("FREQ:SPAN %f GHZ" %span)
    return self.getSpanInGHz()

  ######################
  #  GET TRACES BELOW  #
  ######################

  def getScreen(self, filename):
    self.write("MMEM:STOR:SCR %s, d" %filename)
