# -*- coding: utf-8 -*-
"""
Created on Thu JAN 22 15:17:03 2017

Instrument scripts for Cryomagnetcis G4 Magnet Power Supply

@author: Yui
"""

import sys
import ctypes
import getopt
import re
import struct
import time

from pyview.lib.datacube import Datacube
from pyview.lib.classes import VisaInstrument
#from lib.swig.tools import numerical
import numpy

__DEBUG__=True


#This is the CS instrument.
class Instr(VisaInstrument):

#   this instrument needs a special character termiantions: \r\n
#   it can be validated with the commande (self.)"term_chars = "\r\n""  how to implement this?
    def initialize(self, visaAddress = 'TCPIP0::192.168.0.42::4444::SOCKET', termchars='\r\n', **kwargs):
        try:
          print "Initializing instrument 4G with address %s" % visaAddress
          h = self._handle
          self._visaAddress = visaAddress
          h.term_chars = termchars
        except:
          self.statusStr("An error has occured. Cannot initialize CryoMag B4.")

    
#    def initialize(self, visaAddress = "GPIB0::11::INSTR"):
#        """
#          Initializes the device.
#          """
#        try:
#            self._visaAddress = visaAddress
#            self._currRate=1E-3                             # rate A/sec
#            self._voltRate=1E-3                             # rate V/sec
#            self._currStep=1E-3                             # amps
#            self._voltStep=1E-3                             # volts
#            self._targetCurrent=None
#        except:
#            self.statusStr("An error has occured. Cannot initialize Agilent CS(%s)." % visaAddress)     
            
    def getRemote(self):
        return self.write('REMOTE')

    def getCurrent(self):
        return float(self.ask('IOUT?')[:-1])
    
    def getHeaterStat(self):
        return self.ask('PSHTR?')

    def setHeaterStat(self, value = 'OFF'):
        self.write('PSHTR %s' %value)
        return self.getHeaterStat()

    def getSweepStat(self):
        return self.ask('SWEEP?')

    def getUpperLIM(self):
        return float(self.ask('ULIM?')[:-1])

    def setUpperLIM(self, value = 0):
        self.write('ULIM %s' %str(value))
        return self.getUpperLIM()

    def getLowerLIM(self):
        return float(self.ask('LLIM?')[:-1])

    def setLowerLIM(self, value = 0):
        self.write('LLIM %s' %str(value))
        return self.getLowerLIM()

    def getShimLimit(self):
        return float(self.ask('SLIM?')[:-1])

    def setShimLimit(self, value = 0):
        self.write('SLIM %s' %str(value))
        return self.getShimLimit()


#   UP, DOWN, PAUSE, or ZERO
    def setSweepStat(self, value = 'PAUSE'):
        self.write('SWEEP %s SLOW' %value)
        return self.getSweepStat()

#   set fast mode, most probably for discharging current to start persistent mode operation
    def setSweepFast(self, value = 'PAUSE'):
        self.write('SWEEP %s FAST' %value)
        return self.getSweepStat()

#   rate must be defined in each area
    def getRate(self, sweeprange = 0):
        swprate = float(self.ask('RATE? %s' %str(sweeprange)))        
        return swprate

    def setRate(self, value = 0.0001, sweeprange = 0):
        self.write('RATE %s %s' %(str(sweeprange), str(value)))
        return self.getRate(sweeprange)

    def getRateAll(self):
        for sweeprange in range(5):
	        return self.getrate(sweeprange)

    def setRateAll(self, value = 0.0001):
        for sweeprange in range(5):
        	self.setrate(value, sweeprange)

#   define the limit in each range 
    def getRangeLimit(self, sweeprange = 0): # to define in a finite area?
        return self.ask('RANGE? %s' %str(sweeprange))

    def setRangeLimit(self, value = 5, sweeprange = 0):
        self.write('RANGE %s %s' %(str(sweeprange), str(value)))
        return self.getRangeLimit()

    def getMode(self):
        return self.ask('MODE?')

    def getShim(self):
        return self.ask('SHIM?')

    def setShim(self, value = 'Enable', WhichSHIM = 'Z3'):
        self.write('SHIM %s %s' %(str(value), str(WhichSHIM)))
        return self.ask('SHIM?')

    def getVLim(self):
        return self.ask('VLIM?')
		
    def setVLim(self, value = 0.5):
        self.write('VLIM %s' %(str(value)))
        return self.getVLim() 

    def getMagnetVolt(self):
        return float(self.ask('VMAG?')[:-1])

    def getCurrentCube(self):
        d=Datacube('current')
        currentStr = self.getCurrent()
        currentFloat = float(currentStr[:-1])			# remove the last char ('A')
        d.createCol(name="MagnetCurrent", values = currentFloat)
        return d