
# imports
import sys,getopt,re,struct,time,math
from pyview.lib.classes import VisaInstrument

class Trace:
      pass

class Instr(VisaInstrument):

    """
    The Signal Instrument lock in instrument class
    """

    def initialize(self,visaAddress = "GPIB0::13",slewrate = None):
      """
      Initializes the device.
      """
      try:
        self._visaAddress = visaAddress
      except:
        self.statusStr("An error has occured. Cannot initialize lockin(%s)." % visaAddress)        

    def id(self):
      """
      Returns the identifier of the lock-in
      """
      return self.ask('ID')

    def front_osc_amplitude(self):
      """
      Returns the oscillator amplitude
      """
      return self.ask('XY[.]')
      
    def phase(self):
      """
      Returns the oscillator amplitude
      """
      return self.ask('PHA[.]')


         
    