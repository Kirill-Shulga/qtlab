# imports
import os,sys,getopt,time,traceback,scipy,scipy.optimize,scipy.interpolate
import numpy as np
from pyview.lib.classes import *
from pyview.lib.datacube import Datacube
from pyview.helpers.instrumentsmanager import InstrumentManager
from macros.optimization import Minimizer
reload(sys.modules['macros.optimization'])
from macros.optimization import Minimizer

class Instr(Instrument):
  """
  Combines all three AMI power supplies to run together
  Created by J. Ball and M. Ohta, July 2020
  Get setpoints added by YK, Feb 2021
  """
  def initialize(self, AMIx, AMIy, AMIz):
    """
    Initialize instrument.
    """
    instrumentManager=InstrumentManager() 
    self._amiX=instrumentManager.getInstrument(AMIx)
    self._amiY=instrumentManager.getInstrument(AMIy)
    self._amiZ=instrumentManager.getInstrument(AMIz)
    self._params=dict()
    self._params["AMIx"]=AMIx
    self._params["AMIy"]=AMIy
    self._params["AMIz"]=AMIz
    self._theta = 0
    self._phi = 0

  def rampXYZ(self, fieldMod=0, thetaDeg=0, phiDeg=0, rampRate=0.5):
    """
    Ramp to a given value while preserving the misalignment angle
    Use this one in QuantroPy
    """
    
    # calculate misalignment angles in radians
    theta =float(thetaDeg * np.pi/180) # misalignment about y (along x-axis)   
    phi = float(phiDeg * np.pi/180) # misalignment about x (along y-axis)
    self._theta = thetaDeg
    self._phi = phiDeg      
    
    # do some matrix algrebra
    Bnom = np.array([0, 0, 0.001*fieldMod])
    Ay = np.array([[np.cos(theta), 0, np.sin(theta)], [0,1,0], [-np.sin(theta), 0, np.cos(theta)]] ) # transpose?? 07/10 mori
    Ax = np.array([[1,0,0],[0, np.cos(phi), -np.sin(phi)],[0, np.sin(phi), np.cos(phi)]]) # transpose?? 07/10 mori
    Btilt = np.dot(Ax,np.dot(Ay,np.transpose(Bnom))) # Ax @ (Ay @ Bnom.T)

    normalized_B = Btilt / np.sqrt(np.sum(Btilt**2))
    rampRates = (0.001*rampRate) * normalized_B
    
    #check for quench
    if not self._amiX.canStartRamp():  
        return 'cannot start ramping amiX yet' 
    if not self._amiY.canStartRamp():  
        return 'cannot start ramping amiY yet'            
    if not self._amiZ.canStartRamp():  
        return 'cannot start ramping amiZ yet'
        
    # Check we aren't violating field limits
    field_lim = self._amiX.getFieldLim()
    if np.abs(Btilt[0]) > field_lim:
        return 'The field of amiX is too damn high!'
        
    field_lim = self._amiY.getFieldLim()
    if np.abs(Btilt[1]) > field_lim:
        return 'The field of amiY is too damn high!'
  
    field_lim = self._amiZ.getFieldLim()
    if np.abs(Btilt[2]) > field_lim:
        return 'The field of amiZ is too damn high!'    
        
    # Then, do the actual ramp
    # Set the ramp target
    self._amiX.write("CONF:FIELD:TARG %f" % Btilt[0])
    self._amiY.write("CONF:FIELD:TARG %f" % Btilt[1])
    self._amiZ.write("CONF:FIELD:TARG %f" % Btilt[2])
    
    #adjust Ramp rates     
    self._amiX.setRampRate(np.abs(rampRates[0]))   
    self._amiY.setRampRate(np.abs(rampRates[1]))
    self._amiZ.setRampRate(np.abs(rampRates[2]))
    
    # then start! 
    self._amiX.write("RAMP")
    self._amiY.write("RAMP")
    self._amiZ.write("RAMP")

    #check if finished
    state = float(self._amiZ.getRampingState())
    while state == 1:
        state = float(self._amiZ.ask("STATE?"))
        time.sleep(0.3)
    time.sleep(1.0)
    
    if state != 2:
        return 'setField failed.'
        
  def getField(self):
    results = np.array([float(self._amiX.ask("FIELD:MAG?")), float(self._amiY.ask("FIELD:MAG?")), float(self._amiZ.ask("FIELD:MAG?"))])
    return results
 
  def getFieldSetpoints(self):
    results = np.array([float(self._amiX.getFieldSetpoint()), float(self._amiY.getFieldSetpoint()), float(self._amiZ.getFieldSetpoint())])
    return results

  def getFieldMag(self):
    results = np.sqrt(np.sum(self.getField()**2))
    return results

  def getAngles(self):
    results = [self._theta, self._phi]
    return results

  def rotateXYZ(self, newTheta, newPhi, numSteps=100, rampRate=0.5): 
    """
    Change theta and phi to new values while preserving field magnitude
    """
    if (newTheta > self._theta) == 0:
         thetaValues =  np.linspace(self._theta, newTheta, numSteps)* np.pi/180
    else:
         thetaValues = np.linspace(newTheta, self._theta, numSteps)* np.pi/180
    if (newPhi > self._phi) == 0:
         phiValues = np.linspace(self._phi, newPhi, numSteps)* np.pi/180
    else:
         phiValues = np.linspace(newPhi, self._phi, numSteps)* np.pi/180
       
    Bnom = np.array([0, 0, self.getFieldMag()])
    
    for x in range(0,numSteps-1):
    
    # do some matrix algrebra
        
        Ay = np.array([[np.cos(thetaValues[x]), 0, np.sin(thetaValues[x])], [0,1,0], [-np.sin(thetaValues[x]), 0, np.cos(thetaValues[x])]] ) # transpose?? 07/10 mori
        Ax = np.array([[1,0,0],[0, np.cos(phiValues[x]), -np.sin(phiValues[x])],[0, np.sin(phiValues[x]), np.cos(phiValues[x])]]) # transpose?? 07/10 mori
        Btilt = np.dot(Ax,np.dot(Ay,np.transpose(Bnom))) # Ax @ (Ay @ Bnom.T)

        normB = Btilt / np.sqrt(np.sum(Btilt**2))
        rampRates = rampRate/1000 * normB
        
    # Then, do the actual ramp
    # Set the ramp target
        self._amiX.write("CONF:FIELD:TARG %f" % Btilt[0])
        self._amiY.write("CONF:FIELD:TARG %f" % Btilt[1])
        self._amiZ.write("CONF:FIELD:TARG %f" % Btilt[2])
    
    #adjust Ramp rates     
        self._amiX.setRampRate(rampRates[0])    
        self._amiY.setRampRate(rampRates[1])
        self._amiZ.setRampRate(rampRates[2])
    
    # then start! 
        self._amiX.write("RAMP")
        self._amiY.write("RAMP")
        self._amiZ.write("RAMP")

    #check if finished
    state = float(self._amiZ.getRampingState())
    while state == 1:
        state = float(self.ask("STATE?"))
        time.sleep(0.1)

    self._theta = thetaDeg
    self._phi = phiDeg       
    
    print "FIELD NOW AT NEW ANGLES %f , %f" % (self._theta, self._phi)

             
  def rotateInPlane(self, targTheta, targPhi, rotArg = 1, argRange = 360, rampRate=0.5):
    """
    Rotates the field about a given vector
    By Morihiro, July 2020
    """
    
    theta = float(targTheta * np.pi / 180)
    phi = float(targPhi * np.pi/180) 
    
    currentVec = self.getField()
    targVec = np.array([np.sin(theta)*np.cos(phi), np.sin(theta)*np.sin(phi), np.cos(theta)])
    
    n = np.cross(currentVec, targVec)
    norm_n = np.linalg.norm(n) 
    n = n / norm_n
    _rotArg = float(rotArg * np.pi /180)
    
    rampRates = rampRate/1000 * norm_n
    
    RodMatrics = np.array([
    [n[0]*n[0]*(1 - np.cos(_rotArg)) + np.cos(_rotArg), n[0]*n[1]*(1 - np.cos(_rotArg)) - n[2] * np.sin(_rotArg), n[2]*n[0]*(1 - np.cos(_rotArg)) + n[1] * np.sin(_rotArg)],
    [n[0]*n[1]*(1 - np.cos(_rotArg)) + n[2] * np.sin(_rotArg), n[1]*n[1]*(1 - np.cos(_rotArg)) - np.cos(_rotArg), n[1]*n[2]*(1 - np.cos(_rotArg)) - n[0] * np.sin(_rotArg)],
    [n[2]*n[0]*(1 - np.cos(_rotArg)) - n[1] * np.sin(_rotArg), n[1]*n[2]*(1 - np.cos(_rotArg)) - n[0] * np.sin(_rotArg), n[2]*n[2]*(1 - np.cos(_rotArg)) + np.cos(_rotArg)],
    ]) # Rodrigues rotation formula
    
    rot = []    
    
    for i in range(0,argRange):
        if i == 0:
            rot = np.dot(RodMatrics, currentVec)
            
        else:
            rot = np.dot(RodMatrics, rot)
        
        # Then, do the actual ramp
        # Set the ramp target
        self._amiX.write("CONF:FIELD:TARG %f" % rot[0])
        self._amiY.write("CONF:FIELD:TARG %f" % rot[1])
        self._amiZ.write("CONF:FIELD:TARG %f" % rot[2])
    
        #adjust Ramp rates     
        self._amiX.setRampRate(rampRates[0])    
        self._amiY.setRampRate(rampRates[1])
        self._amiZ.setRampRate(rampRates[2])
    
        # then start! 
        self._amiX.write("RAMP")
        self._amiY.write("RAMP")
        self._amiZ.write("RAMP")

    #check if finished
    state = float(self._amiZ.getRampingState())
    while state == 1:
        state = float(self.ask("STATE?"))
        time.sleep(0.1)
    
    
  
          
